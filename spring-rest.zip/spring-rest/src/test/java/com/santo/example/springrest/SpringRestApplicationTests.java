package com.santo.example.springrest;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
