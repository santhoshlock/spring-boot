insert into user values (11000, sysdate(),'cheeku');
insert into user values (11001, sysdate(),'chikki');
insert into user values (11002, sysdate(),'chokku');

insert into post values (12000, 'My first Post',11000);
insert into post values (12001, 'My second Post',11000);
insert into post values (12002, 'My third Post',11002);